# TicketOfficeCP
Project made during high school in the 12th grade, which simulates a train ticket office of Comboios de Portugal (CP)
