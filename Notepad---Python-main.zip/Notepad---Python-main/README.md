# Notepad---Python
Notepad programmed in python
