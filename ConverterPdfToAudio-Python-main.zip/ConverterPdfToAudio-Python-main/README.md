# ConverterPdfToAudio-Python
Programming converter pdf to audio in Python
